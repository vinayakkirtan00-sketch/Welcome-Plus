<?php

declare(strict_types=1);

namespace WelcomePlus;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Main extends PluginBase implements Listener {

    private Config $config;

    public function onEnable(): void {
        $this->saveDefaultConfig();
        $this->config = $this->getConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();
        $message = $this->config->get("welcome", "&aWelcome {player} to &6Our Server! &eEnjoy your stay! &aOnline: {online}");
        $message = str_replace("{player}", $player->getName(), $message);
        $message = str_replace("{online}", (string) count($this->getServer()->getOnlinePlayers()), $message);
        $message = $this->colorize($message);
        $this->getServer()->broadcastMessage($message);
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $message = $this->config->get("leave", "&c{player} &ehas left the world!");
        $message = str_replace("{player}", $player->getName(), $message);
        $message = str_replace("{online}", (string) (count($this->getServer()->getOnlinePlayers()) - 1), $message); // Adjust for post-quit count if {online} is used
        $message = $this->colorize($message);
        $this->getServer()->broadcastMessage($message);
    }

    private function colorize(string $message): string {
        return str_replace("&", "§", $message);
    }
}